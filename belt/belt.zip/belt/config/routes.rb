Rails.application.routes.draw do
	resources :users
	root 'users#index'

	post '/ideas' => 'ideas#create'
	delete '/ideas/:id' => 'ideas#destroy'

	post '/login' => 'users#login'
	get '/bright_ideas' => 'ideas#index'
	get '/bright_ideas/:id' => 'ideas#show'
	delete '/logout' => 'users#logout'

	post '/likes' => 'likes#create'
end
