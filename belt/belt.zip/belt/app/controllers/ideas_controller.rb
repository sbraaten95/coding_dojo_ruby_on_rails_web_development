class IdeasController < ApplicationController
	def index
		@user = current_user
		render 'index'
	end
	def create
		@user = current_user
		Idea.create(content:params[:idea], user:@user)

		redirect_to '/bright_ideas'
	end
	def show
		@post = Idea.find(params[:id])
		render 'show'
	end
	def destroy
		@idea = Idea.find(params[:id])
		@idea.destroy if @idea.user == current_user

		redirect_to '/bright_ideas'
	end
end
