class SecretsController < ApplicationController
	def index
		render 'index'
	end
end
